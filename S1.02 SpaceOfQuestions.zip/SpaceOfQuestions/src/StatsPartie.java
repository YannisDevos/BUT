class StatsPartie {
    int score;
    int nbBonneRep;
    int nombreQuestPosées;
}