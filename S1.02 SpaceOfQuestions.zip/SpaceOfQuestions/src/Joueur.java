class Joueur {

    String nomUtilisateur;
    String mdp;
    String meilleurScoreFacile;
    String meilleurScoreNormal;
    String meilleurScoreDifficile;
    String meilleurScoreMortSubite;

}